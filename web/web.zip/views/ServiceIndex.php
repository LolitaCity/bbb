<!DOCTYPE html>
<!-- saved from url=(0039)https://qqq.wkquan.com/Fine/VTask/Index -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title></title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="renderer" content="webkit">
    <script src="./Index_files/jquery-1.8.3.js.下载" type="text/javascript"></script>
    <script src="./Index_files/jquery.jslides.js.下载" type="text/javascript"></script>
    <script src="./Index_files/open.win.js.下载" type="text/javascript"></script>
    <script src="./Index_files/jquery.vticker-min.js.下载" type="text/javascript"></script>
    <link href="./Index_files/common.css" rel="stylesheet" type="text/css">
    <link href="./Index_files/index.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="./Index_files/open.win.css">
    <link rel="stylesheet" type="text/css" href="./Index_files/custom.css">
    <style type="text/css">
    .notice{
        width:510px !important;
        height: 35px;
        line-height: 35px;
        border:1px solid #fed89e;
        padding-left:35px;
        color: #222;
        background:url('/Content/images/notice.png') no-repeat 10px center #fdf9f3;
        position:relative;
        font-size: 14px;
        float:left;
        text-align:left;
        margin-left:45px;
        margin-top:20px;
    }
    .notice em{color:red; font-style: inherit;}
    .notice ul{width: 100%; list-style: none;}
    .notice li{padding: 0px 2px;background: #fdf9f3;}
    .notice_num{display:block; width:18px; height:18px; background:red; color:#fff; text-align: center; line-height: 18px; border-radius: 100%; position: absolute; top:0px; z-index: 99; left: 15px;}
</style>

    <style type="text/css">
       
.navbg {
	width: 100%;
	height: 48px;
	background: #0866c6;
	overflow: hidden;
}
.nav {
	--width: 73%;--sz0610
	margin: 0 auto;
	font-size: 14px;
}
.nav li {
	float: left;
	display: inline;
}
.nav a {
	color: #fff;
	line-height: 48px;
	padding: 0 23px;
	display: block;
	height: 48px;
	float: left;
}
.nav a:hover, .nav a.a_on {
	background: #0756a6;
	color: #fff;
	text-decoration: none;
}
.nav li.frt-btn {
	float: right;
}
.nav li.frt-btn a {
	background: #86ce4b url(../images/indexicon.png) no-repeat 17px -232px;
	width: 126px;
	padding: 0;
	text-align: left;
	text-indent: 51px;
}
.nav li.frt-btn a:hover {
	background: #7dc840 url(../images/indexicon.png) no-repeat 17px -232px;
}
        
.sj-nav {
    font-family: "微软雅黑";
    font-size: 14px;
    height: 50px;
    margin: 0 auto;
    width: 1200px;
}
          .sj-nav li a {
    color: #fff;
    display: block;
    height: 50px;
    line-height: 50px;
    text-align: center;
    width: 100px;
}
        caption, th
        {
            text-align: center;
        }
        .input-radio16
        {
            border: 1px solid #ddd;
            height: 15px;
            width: 16px;
        }
        .black_overlay
        {
            background-color: black;
            display: none;
            height: 100%;
            left: 0;
            opacity: 0.8;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 1001;
        }
    </style>
    <style type="text/css">
       
        .navbg {
	width: 100%;
	height: 48px;
	background: #0866c6;
	overflow: hidden;
}
.nav {
	--width: 73%;--sz0610
	margin: 0 auto;
	font-size: 14px;
}
.nav li {
	float: left;
	display: inline;
}
.nav a {
	color: #fff;
	line-height: 48px;
	padding: 0 23px;
	display: block;
	height: 48px;
	float: left;
}
.nav a:hover, .nav a.a_on {
	background: #0756a6;
	color: #fff;
	text-decoration: none;
}
.nav li.frt-btn {
	float: right;
}
.nav li.frt-btn a {
	background: #86ce4b url(../images/indexicon.png) no-repeat 17px -232px;
	width: 126px;
	padding: 0;
	text-align: left;
	text-indent: 51px;
}
.nav li.frt-btn a:hover {
	background: #7dc840 url(../images/indexicon.png) no-repeat 17px -232px;
}
        
.sj-nav {
    font-family: "微软雅黑";
    font-size: 14px;
    height: 50px;
    margin: 0 auto;
    width: 1200px;
}
          .sj-nav li a {
    color: #fff;
    display: block;
    height: 50px;
    line-height: 50px;
    text-align: center;
    width: 100px;
}
        caption, th
        {
            text-align: center;
        }
        .input-radio16
        {
            border: 1px solid #ddd;
            height: 15px;
            width: 16px;
        }
        .black_overlay
        {
            background-color: black;
            display: none;
            height: 100%;
            left: 0;
            opacity: 0.8;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 1001;
        }
    </style>
    <style type="text/css">
        .sj-nav li a
        {
            color: #fff;
            display: block;
            height: 50px;
            line-height: 50px;
            text-align: center;
            width: 100px;
        }
        .index_top_2
        {
            line-height: 80px;
            margin-left: 20px;
        }
        .topusers
        {
            width: 124px;
            height: auto;
            padding: 0 12px 0 0;
            position: relative;
            display: block;
            float: right;
            z-index: 2;
        }
        .topusers a
        {
            color: #fff;
        }
        .topusers .user_x
        {
            width: 122px;
            height: 72px;
            padding: 0 1px;
        }
        .topusers:hover .user_x
        {
            border: 1px solid #246dba;
            border-bottom: 0px;
            border-top: 0px;
            background: #317ccc;
            padding: 0;
        }
        .topusers a
        {
            line-height: 72px;
            display: block;
            height: 72px;
            width: auto;
            padding: 0 0 0 41px;
            cursor: pointer;
            z-index: 4;
            position: relative;
        }
        .topusers i
        {
            background-image: url(../images/onLine.png);
            background-repeat: no-repeat;
            display: block;
            width: 20px;
            height: 20px;
            position: absolute;
            z-index: 5;
            overflow: hidden;
        }
        .topusers .user_x a i.user-Picture
        {
            background-position: 0px -254px;
            left: 10px;
            top: 27px;
        }
        .topusers .user_x a:hover
        {
            text-decoration: none;
            color: #fff;
        }
        .topusers .user_x2
        {
            width: 124px;
            display: none;
            position: absolute;
            z-index: 3;
            top: 72px;
            left: 0px;
            visibility: hidden;
        }
        .topusers:hover .user_x2
        {
            display: block;
            visibility: visible;
        }
        .topusers .user_x2 ul
        {
            display: block;
            width: 122px;
            height: auto;
            overflow: hidden;
            border: 1px solid #2161a6;
            border-top: 0px;
            background: #317ccc;
        }
        .topusers .user_x2 li
        {
            clear: both;
            float: none;
            width: 100%;
            height: auto;
            border-top: 1px solid #246dba;
        }
        .topusers .user_x2 a
        {
            border-top: 1px solid #3c89dc;
            line-height: 36px;
            height: 36px;
            width: auto;
        }
        .topusers .user_x2 a:hover
        {
            background: #3c89dc;
            text-decoration: none;
            color: #fff;
        }
        .topusers .user_x2 a i.user-xpwd
        {
            background-position: 4px -283px;
            left: 10px;
            top: 7px;
        }
        .topusers .user_x2 a i.user-quit
        {
            background-position: 3px -319px;
            left: 10px;
            top: 7px;
        }
    </style>
    <style type="text/css">
  body , ul,li {margin:0; padding:0; color: #222; font-family: "微软雅黑";}
  ol , ul {list-style:none;}
  a {color:#222; text-decoration:none;}
  a:focus{outline:none;} /*for ff f6n.net*/
  a:hover {text-decoration:none;}
  .cpcenter{ position: relative; z-index: 1000; width: 100%; background: #4882f0;height:53px; line-height: 53px;}
  .cpcenter .lside>ul{ width: 1200px; position: relative; margin: 0px auto;}
  .cpcenter .lside>ul>li{ float: left; height: 50px; line-height: 50px; position:relative;border-bottom: 3px solid #4882f0; }
  .cpcenter .lside>ul>li:hover>a{ color:#fff;}
  .cpcenter .lside>ul>li>a{ width: 170px; height: 52px; text-align: center; border-top:none; line-height: 53px;display:block; font-size: 14px; color: #fff; text-decoration: none;}
  .cpcenter .lside>ul>li>em{ background:url('/Content/images/daohanem.png') no-repeat; width: 7px; height: 4px; display: block; position: absolute; top: 24px; left: 130px;}
  .cpcenter .lside>ul>li:hover>em{ background:url('/Content/images/daohanem.png') no-repeat center -7px; width: 7px; height: 4px; display: block; position: absolute; top: 24px; left: 130px;}
  .cpcenter .lside>ul>li:hover{ background:#3b6cca; border-bottom: 3px solid #ff9900; height: 50px; font-weight:bold;}
  .cpcenter .lside>ul>li>span{ display: block; width: 15px; height: 42px;}
  .cpcenter .lside>ul>li ul{ display: none; background: #fff; border-top: none;}
  .cpcenter .lside>ul>li ul li{ height: 42px; line-height: 42px; text-align: center; }
  .cpcenter .lside ul li ul li a{ display: inline-block; color: #000; width: 150px; margin:0px auto; border-bottom: 1px dotted #ccc; font-weight: normal;  border-top: none; font-size: 14px;}
  .cpcenter .lside>ul>li:hover ul{ display: block; width: 170px;border:1px dotted #ccc; border-top: none;}
  .cpcenter .lside>ul>li ul li a:hover{ color: #f90; display:inline-block; width:150px;  font-weight: normal; }
  #mqs{ position: relative; z-index:1002;}
  </style>
    <style type="text/css">
        /*开关按钮*/
        
        .hdtop p
        {
            float: left;
            margin-top: 30px;
            line-height: 30px;
        }
        .banner
        {
            background: url(banner.jpg) no-repeat center top;
            width: 100%;
            height: 400px;
        }
        .ba_mid
        {
            width: 990px;
            margin: 0px auto;
        }
        .ba_w295
        {
            width: 292px;
            height: 280px;
            float: right;
            margin-top: 65px;
        }
        .bg_top1
        {
            background: #f6f4f5;
            height: 200px;
            border-radius: 8px;
            padding: 5px 0px;
        }
        .bg_top1 li
        {
            height: 48px;
            line-height: 48px;
            font-size: 18px;
            border-bottom: 1px solid #dcdfdf;
            padding-left: 55px;
            background:url('/Content/images/quanquan.png') no-repeat 25px center;
         
        }
        .bg_top1 li b
        {
            color: #ff0000;
            font-weight: normal;
        }
        .ba_aniu
        {
            background:url('/Content/images/b_bn_an.png') no-repeat center top;
            height: 67px;
            margin-top: -8px;
        }
        .ba_aniu span
        {
            width: 173px;
            color: #fff;
            float: left;
            line-height: 67px;
            font-size: 18px;
            padding-left: 60px;
        }
    .dianck a{display: none;}
    .dianck{float:right;text-align:center; padding:0px;}
    .ba_aniu:hover .dianck{background:#f90; font-size:14px; transition: all 0.5s ease 0s; height:27px; padding:20px 15px; width:28px;  display:block; opacity:1;  opacity:1;}
    .ba_aniu:hover .dianck a{color:#fff;display:block; margin-top:-2px;}
        
        .skmain_left, .skmain_right
        {
            width: 579px;
            height: 202px;
            font-size: 14px;
            border: 1px solid #ddd;
            margin-top: 40px;
            overflow: hidden;
        }
        .xlh2 h2
        {
            border-bottom: 1px solid #ddd;
            font-size: 14px;
            height: 40px;
            line-height: 40px;
            padding-left: 10px;
            background: #4882f0;
            color: #fff;
        }
     
        #sxyc{font-size: 18px; color:#457ee8; font-weight:bold; position:relative; width: 115px; height: 30px;float:left; margin-top:30px; line-height:30px;}
        .add{background: url(/Content/Images/222.gif)no-repeat; width: 115px; height:30px; }
        .add1{background: url(/Content/Images/111.gif)no-repeat; width: 115px; height: 30px;}
        .cssPrompt ,.cssPrompt1{ background:#fff; color:#222; border:1px solid #f90; width:250px; padding:10px; border-radius:6px; position:absolute; left:-280px; top:-20px; z-index:9999; line-height:20px; font-size:14px; font-weight:normal; font-family: "微软雅黑";display:none;}
        .cssPrompt em ,.cssPrompt1 em{
                        display: block; 
                        position:absolute; 
                        top:25px;
                        right:-8px;
                        width: 0px;
                        height: 0px;
                        border-top:6px solid transparent;
                        border-bottom:6px solid transparent;
                        border-left:7px solid #f90;
                    }
        .add:hover .cssPrompt{ display:block;}    
        .add1:hover .cssPrompt1{ display:block;}
        .csshuiyuan{float:left;}
        .kaiguan{float:right;}
        .csshuiyuan{float:left; margin:35px 0px 0px 50px;}
        .csshuiyuan a{ color: #ff9900;}
        .csshuiyuan a b{ color: #000;margin-right: 10px; font-weight:bold; font-size:16px;}

        /*开关按钮*/
        #Open_x1{width:70px;height:30px; border-radius: 50px; position: relative; margin:28px 0px 10px 10px; float:left;}
        #No_x1{width:28px; height: 28px; border-radius: 48px; position: absolute; background: white;}
        .open1{background:#ccc;}
        .open2{top: 1px; right:1px;}
        .close1{background:#457ee8;border-left: transparent;}
        .close2{top: 1px;left: 1px;}

    </style>
    <script language="javascript" type="text/javascript">
        $(document).ready(function () {
            var memberType='商家'
            if(memberType!="商家")
            {
              $("#aOut").click();
            }
        
            GetOANum();
            GetNoReadCnt();//未读工单数量提醒
            
            $(window).load(function(){
               // GetOnLine();//在线/离线
          
                GetSetOutNum();//未发货数量提醒

                GetNeedUpfileBase();//未到账反馈数量
            });
            
            
        });

        //未发货数量提醒
        function GetSetOutNum(){
          $.ajax({
                type: "get",
                cache:false,
                url: "/Home/GetSetOutNum",
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    //alert("error GetSetOutNum:"+XmlHttpRequest.responseText);
                },
                success: function (data) {
                    if (parseInt(data) >0) {
                   var msg="您有" + data + "个任务已获得运单号,可进行发货了,请及时按流程发货!";
                     $("#sp").text("温馨提示: ");
                     $("#title").text(msg);
                     $("#title").attr("href","/Shop/Task/TaskIndex?status=2");
                    }
                }
            });
        }

        //在线/离线
        function GetOnLine() {
            $.ajax({
                type: "get",
                cache:false,
                url: "/Home/UpdateOnLine",
                data:{flag: 2 },
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    //alert("error GetOnLine:"+XmlHttpRequest.responseText);
                },
                success: function (data) {
                
                    if (data == "True") {
                        //$("#pStatus").text("显示任务");
                        //$("#selectStatus").text("隐藏任务");
                        //$("#imgs").attr("src", '/Content/images/Online.png');
//                        $("#Seleline").val('1');
                  var div2 = document.getElementById("No_x1");
                   var div1 = document.getElementById("Open_x1");
                   //$("#sxyc").html("显示任务 :");
                    div1.className = "close1";
                    div2.className = "close2";
                    $("#sxyc").removeClass("add");
                    $("#sxyc").addClass("add1");
                    }
                    else {
                        //$("#pStatus").text("隐藏任务");
                        //$("#selectStatus").text("显示任务");
                        //$("#imgs").attr("src", '/Content/images/unOnline.png');
//                        $("#Seleline").val('2');
                   var div2 = document.getElementById("No_x1");
                    var div1 = document.getElementById("Open_x1");
                    //$("#sxyc").html("隐藏任务 :");
                    div1.className = "open1";
                    div2.className = "open2";
                    $("#sxyc").removeClass("add1");
                    $("#sxyc").addClass("add");
                    }
                }
            });
        }


        //编辑在线/离线
        function UpdateOnLine() {
            var div2 = document.getElementById("No_x1");
            var div1 = document.getElementById("Open_x1");
            $.ajax({
                type: "get",
                cache:false,
                url: "/Home/UpdateOnLine",
                data:{flag: 1 },
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    //alert("error UpdateOnLine:"+XmlHttpRequest.responseText);
                },
                success: function (data) {
                    if (data == "True") {
                        //$("#sxyc").html("显示任务 :");
                        div1.className = "close1";
                        div2.className = "close2";
                        $("#sxyc").removeClass("add");
                        $("#sxyc").addClass("add1");
                        $.openAlter('亲，您当前处于“在线”状态，您所发布的销量任务将会正常被接手。', '提示', { width: 250, height: 50 }, null, "好的");
                    }
                    else if(data == "False"){
                        //$("#sxyc").html("隐藏任务 :");
                        div1.className = "open1";
                        div2.className = "open2";
                        $("#sxyc").removeClass("add1");
                        $("#sxyc").addClass("add");
                        $.openAlter('亲，您当前处于“隐身”状态。您所发布的销量任务将<span style="color:red">全部被系统隐藏</span>，买手将<span style="color:red">无法接手您发布的任务</span>。如有疑问请咨询客服QQ：800186664', '提示', { width: 250, height: 50 }, null, "好的");
                    }else if(data == "存在超时未转账订单"){
                        $.openAlter('亲，您未在转账截止时间内对“等待转账”的<br/>提现申请进行转账，系统自动将您的状态调为<br/><span style="color:red">隐藏任务</span>，不可恢复<span style="color:red">显示任务</span>状态。请立即<br/>进行转账处理。'
                        , '提示', { width: 250, height: 50 }
                        , function(){ self.parent.location = "/Shop/TransferManagement";}, "立即转账");  
                    }
                    else if(data == "存在超时未上传凭证的订单"){
                         $.openAlter('亲，您存在<span style="color:red">超时未上凭传证</span>的订单，系统已将<br/>您的状态调为“<span style="color:red">隐藏任务</span>”，不可恢复“显示<br/>任务”状态。请上传凭证后再对状态进行调<br/>整。'
                        , '提示', { width: 250, height: 50 }
                        , function(){ self.parent.location = "/Shop/TransferManagement/BackResult";}, "立即上传");  
                    }
                    else{
                        $.openAlter(data, '提示', { width: 250, height: 50 }, null, "好的");
                    }
                }
            });

        }


        function GetLine()
        {   
             var val=$("#Seleline").val();
             UpdateOnLine();
             
        }
        //未读工单提醒
        function GetNoReadCnt(){
            $.ajax({
                type: "get",
                cache:false,
                url: "/Home/GetNoReadCnt",
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    //alert("error GetNoReadCnt:"+XmlHttpRequest.responseText);
                },
                success: function (data) {
                    if(data!=0){
         
                        var info='客服工单<strong><font color="#ff9900">('+data+')</font></strong>';
                        $("#Schedual").html(info);
                    }
                }
            });
        }
        function GetOANum()
        {
           $.post('/Fine/VTaskQA/GetQANum',{},function(result){
          if(result>0)
          {
             var info='评价任务<strong><font color=red>('+result+')</font></strong>';
             $("#VMVipTask a:eq(3)").html(info);
          }
           },"json");
        }
        function vipTask()
        {
           var submit = function (v, h, f) {
                    if (v == true)
                    {
                      location.href="/Fine/VMTask";
                     }
                    else
                     {
                          location.href="/Shop/VipTask/VipTaskOne";
                     }
                      return true;
                    };
                  // 自定义按钮
                     jBox.confirm("精刷任务已上线，真实买家，一人一号，永不复购，你不体验一下吗？", "温馨提示", submit, { id: 'hahaha', top: 250,draggable:false, buttons: { '马上体验': true, '下次再说': false} });
                     return false;
        }

        function tryVTrafficTask()
        {
            $.openConfirm(
            '<div style="text-align:left">经过观察发现，现在机器导入的流量已经不能给商品带来任何权重，而且流量的数据异常还有可能引起系统的排查。为了保障各位卖家用户的店铺安全，我们决定从即日起关闭通过机器导入的流量配合业务。如果需要流量配合的卖家，建议选择我们的淘宝APP人工流量。</div>'
            , '温馨提示'
            , { width: 250, height: 50 }
            , function () { location.href="/Fine/VTrafficTask"; }, "现在去试试"
            , function () { location.href="http://qqq.wkquan.com/Other/Content/NNewsInfo?id=68"; }, "了解详情"
            );
            return false;
        }

        function GetNeedUpfileBase(){
            $.ajax({
                type: "get",
                cache: false,
                url: "/Shop/TransferManagement/GetNeedUpfile",
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    //alert("error GetNoReadCnt:"+XmlHttpRequest.responseText);
                },
                success: function (data) {
                    if(data!=null){
                        if(data!=0)
                        {
                            var info='转账管理<strong><font color=red> ( '+data+ ' ) </font></strong>';
                            $("#transferManagement a").html(info);
                        }
                    }
                }
            });
        }
    </script>
    <script type="text/javascript">
        $(function () {
            var div2 = document.getElementById("No_x1");
            var div1 = document.getElementById("Open_x1");
            $("#liVipTask").click(function () {
                location.href="/Shop/VipTask/VipTaskOne?flag=1"; 
                 return false;
            });
            $("#No_x1").click(function () {
                UpdateOnLine();
                //                if (div1.className == "open1") {
                //                    $("#sxyc").removeClass("add");
                //                    $("#sxyc").addClass("add1");
                //                    div1.className = "close1";
                //                    div2.className = "close2";

                //                }
                //                else {
                //                    $("#sxyc").removeClass("add1");
                //                    $("#sxyc").addClass("add");
                //                    div1.className = "open1";
                //                    div2.className = "open2";
                //                }
            });
        });
    </script>


    
    <script src="./Index_files/md5.js.下载" type="text/javascript"></script>
    <script src="./Index_files/jquery.jBox-2.3.min.js.下载" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="./Index_files/jbox.css">
    
    <style type="text/css">
     
        .navbg {
	width: 100%;
	height: 48px;
	background: #0866c6;
	overflow: hidden;
}
.nav {
	--width: 73%;--sz0610
	margin: 0 auto;
	font-size: 14px;
}
.nav li {
	float: left;
	display: inline;
}
.nav a {
	color: #fff;
	line-height: 48px;
	padding: 0 23px;
	display: block;
	height: 48px;
	float: left;
}
.nav a:hover, .nav a.a_on {
	background: #0756a6;
	color: #fff;
	text-decoration: none;
}
.nav li.frt-btn {
	float: right;
}
.nav li.frt-btn a {
	background: #86ce4b url(../images/indexicon.png) no-repeat 17px -232px;
	width: 126px;
	padding: 0;
	text-align: left;
	text-indent: 51px;
}
.nav li.frt-btn a:hover {
	background: #7dc840 url(../images/indexicon.png) no-repeat 17px -232px;
}
    #VMVipTask
        {
        background:#3b6cca; 
        color: White;
        }
     .menudiv,.tab1,.sj-fprw{ overflow:visible;}
   .disquxioa{ position:relative;}
     .diszhushi em{display: block; left:85px; position:absolute;  top:50px; width: 0px; height: 0px; 
                  border-left:5px solid transparent; 
                  border-right:5px solid transparent;
                  border-top:7px solid #f90;}
   .diszhushi{display:none;position:absolute; left:-50px; top:-65px; height:39px; border:1px solid #f90; padding:5px; background:#fff; border-radius:5px; width:225px}

   .disquxioa:hover .diszhushi{display:block; }
.display_block{ position:relative; display:block; margin:10px auto 0px;}
     .display_block:hover{color:#fff !important;}
     .display_block:hover .dis_black_tc{display:block;}
    .dis_black_tc{border-radius:5px; border:1px solid #4782ef; width:200px; padding: 10px; font-size:14px; color:#666; text-align:left; line-height:20px; left:-50px; display:none; position:absolute; bottom:-108px;background-color:White}
    .dis_black_tc em{background:url('/Content/images/display_jt.png'); width:12px; height:6px; top:-6px; left:95px; position:absolute; display:block;}
    .fprw-pg{overflow: inherit !important;}
    </style>
    <script src="./Index_files/laydate.js.下载" type="text/javascript"></script><link type="text/css" rel="stylesheet" href="./Index_files/laydate.css"><link type="text/css" rel="stylesheet" href="./Index_files/laydate(1).css" id="LayDateSkin">
    <script>
        $(function () {
            $("#VMVipTask").addClass("#VMVipTask");
            var taskNum = '4';
            var statuValue = $("#status").val();
            if (parseInt(taskNum) > 0 && statuValue != null && (parseInt(statuValue) == 0 || parseInt(statuValue) == 6)) {
                $("#btnCancel").attr("class", "input-butto100-hs");
                $("#btnCancel").attr("disabled", null);
                $("#btnCancel").css("background", "#12BD37");
                $(".diszhushi").hide();
            }
            else if (parseInt(taskNum) == 0 && (parseInt(statuValue) == 0 || parseInt(statuValue) == 6)) {
                $(".diszhushi").hide();
            }

        })
        function setTab(name, cursel) {
            cursel_0 = cursel;
            for (var i = 1; i <= links_len; i++) {
                var menu = document.getElementById(name + i);
                var menudiv = document.getElementById("con_" + name + "_" + i);
                if (i == cursel) {
                    menu.className = "off";
                    menudiv.style.display = "block";
                }
                else {
                    menu.className = "";
                    menudiv.style.display = "none";
                }
            }
        }
        function Next() {
            cursel_0++;
            if (cursel_0 > links_len) cursel_0 = 1
            setTab(name_0, cursel_0);
        }
        var name_0 = 'one';
        var cursel_0 = 1;
        var links_len, iIntervalId;
        onload = function () {
            var links = document.getElementById("tab1").getElementsByTagName('li')
            links_len = links.length;
            for (var i = 0; i < links_len; i++) {
                links[i].onmouseover = function () {
                    clearInterval(iIntervalId);
                    this.onmouseout = function () {
                        iIntervalId = setInterval(Next, ScrollTime); ;
                    }
                }
            }
            document.getElementById("con_" + name_0 + "_" + links_len).parentNode.onmouseover = function () {
                clearInterval(iIntervalId);
                this.onmouseout = function () {
                    iIntervalId = setInterval(Next, ScrollTime); ;
                }
            }
            setTab(name_0, cursel_0);
            iIntervalId = setInterval(Next, ScrollTime);
        }
    </script>
    <script type="text/javascript">
        //取消任务
        function CancelTask(taskID) {
            $.openWin(320, 700, '/Fine/VTask/CancelTask?taskID=' + taskID);
        }
        //取消全部带接手任务
        function CancelAllTask() {
            if ($("#status").val() != "0" && $("#status").val() != "6") {
                $.openAlter("查询条件为<em style=\"color:red\">“待接手”</em>或<em style=\"color:red\">“隐藏任务”</em> ，才能进行批量取消任务操作。", "温馨提示");
                return false;
            }
            var status = $("#status").val();
            var taskCategroy = $("#taskCategroy").val();
            var beginDate = $("#BeginDate").val();
            var endDate = $("#EndDate").val();
            var selSearch = $("#selSearch").val();
            var txtSearch = $("#txtSearch").val();
            if (taskCategroy == null || taskCategroy == '')
                taskCategroy = -1;
            $.openWin(220, 400, '/Fine/VTask/CancelAllTask?status=' + status + '&fineTaskCategroy=' + taskCategroy + '&startTime=' + beginDate + '&endTime=' + endDate + '&selSearch=' + selSearch + '&txtSearch=' + txtSearch);
        }
        //取消接手任务
        function CancelAcceptTask(taskID) {
            $.openWin(250, 500, '/Fine/VTask/CancelAcceptTask?taskID=' + taskID);
        }
        //隐藏任务
        function HideTask(taskID) {
            $.openWin(220, 500, '/Fine/VTask/HideTask?taskID=' + taskID);
        }
        //显示任务
        function ShowTask(taskID) {
            $.openWin(220, 500, '/Fine/VTask/ShowTask?taskID=' + taskID);
        }
        //修改备注
        function EditTaskRemark(taskID) {
            $.openWin(280, 500, '/Fine/VTask/EditTaskRemark?taskID=' + taskID);
        }
        //查看京东买号信息
        function LookJdBuyNumberInfo(id) {
            $.openWin(380, 450, '/Fine/VTask/GetJDDetailInfo?id=' + id);
        }
        //查看买号信息
        function LookBuyNumberInfo(id) {

            $.openWin(380, 450, '/Fine/VTask/GetDetailInfo?id=' + id);
            //            $.openWin(380, 700, '/Fine/VTask/LookBuyNumberInfo?taskID=' + taskID);
        }
        //查看任务详情
        function GetTaskDatailInfo(taskID) {
            $.openWin(680, 700, '/Fine/VTask/GetTaskDatailInfo?taskID=' + taskID);
        }
        //查看任务截图
        function GetPictures(taskID) {
            $.openWin(580, 1000, '/Fine/VTask/GetPictures?taskID=' + taskID);
            document.getElementById(taskID).style.background = "#666";
            document.getElementById(taskID).value = "已查看";
        }

        //商家发货
        function ShopFaHuo(taskID, orderID) {
            $.openWin(480, 500, '/Fine/VTask/FaHuo?taskID=' + taskID + '&orderID=' + orderID);
        }
        //商家审核通过
        function FinishTask(taskID) {
            $.openWin(300, 500, '/Fine/VTask/FinishTask?taskID=' + taskID);
        }
        //商家创建任务出错
        function CreateTaskError(taskID) {
            $.openWin(590, 550, '/Fine/VTask/CreateTaskError?taskID=' + taskID);
        }
        //查看任务日志
        function ShowOptLog(taskID) {
            $.openWin(560, 850, '/Fine/VTask/TaskOptLog?taskID=' + taskID);
        }
        function NoSet() {
            $.openAlter("客官别急，快递尚未反馈空包单号，请稍后再发货~", "温馨提示");
        }
        function GetDifferenceInfo(taskID) {
            $.openWin(340, 480, '/Fine/VTask/GetDifferencePriceInfo?taskID=' + taskID);
        }
    </script>


</head>
<body style="background: #fff;">
    <!--[if lt IE 8]>

<script language="javascript" type="text/javascript">
$.openAlter('<div style="font-size:18px;text-align:left;line-height:30px;">hi,你当前的浏览器版本过低，可能存在安全风险，建议升级浏览器：<div><div style="margin-top:10px;color:red;font-weight:800;">谷歌Chrome&nbsp;&nbsp;,&nbsp;&nbsp;UC浏览器</div>', "提示", { width: 250, height: 50 });
$("#ow_alter002_close").remove();
</script>
<![endif]-->
    <div class="index_top">
        <div class="index_top_1">
            
            <!-- 头部 -->
            
            <p class="left">
                <img src="./Index_files/logo.png"></p>
            <div id="news-container1" class="notice">
                <!--   <font class="notice_num">2</font> -->
                <ul>
                    <li>9月21日起，平台所有数据只保留<em>50</em>天，超时将永久删除，请提前做好对账工作。</li>
                
                </ul>
                <!-- <a href="" class="next"></a> -->
            </div>
            <div class="kaiguan">
                    <div id="sxyc" class="add1">
                        <div class="cssPrompt">
                            <em></em>亲，您当前处于隐身状态，所发布的销量任务全部被系统隐藏，买手无法接手！
                        </div>
                        <div class="cssPrompt1">
                            <em></em>亲，您当前处于在线状态，所发布的销量任务能正常被买手接手。
                        </div>
                    </div>
                    <div id="Open_x1" class="close1">
                        <div id="No_x1" class="close2">
                        </div>
                    </div>
                <span class="csshuiyuan"><a href="javascript:void(0)"><b>霆宇包包</b></a><a id="aOut" href="javascript:void(0)" onclick="javascript:location=&#39;/Login/LogOut&#39;">退出</a></span>
            </div>
            <marquee id="mqs" direction="Left" scrollamount="4">
   <span style="color:Red" id="sp"> </span><span style="color:White"><a id="title" style="color:White"></a> </span> 
         </marquee>
            <!-- 头部 -->
               
        </div>
    </div>
    
    <!--daohang-->
    <div class="cpcenter">
        <div class="lside container">
            <ul class="cpmenulist">
                <li><a href="https://qqq.wkquan.com/Home/ShopIndex" id="ShopIndex">首页</a></li>
                <li id="VMVipTask" class="#VMVipTask"><a>销量任务管理</a><em></em>
                    <ul>
                        <li><a href="https://qqq.wkquan.com/Fine/VMTask/Index">发布任务</a></li>
                        <li><a href="https://qqq.wkquan.com/Fine/VTask/Index">任务管理</a></li>
                        <li><a href="https://qqq.wkquan.com/Fine/VEvaluateTask/Index">评价管理</a></li>
                    </ul>
                </li>
                <li><a id="VipTask">日常任务管理</a><em></em>
                    <ul>
                        <li id="liVipTask"><a href="https://qqq.wkquan.com/Shop/VipTask/VipTaskOne">发布任务</a></li>
                        <li><a href="https://qqq.wkquan.com/Shop/Task/TaskIndex">发布管理</a></li>
                    </ul>
                </li>
                    <li><a id="TaskApp">淘宝APP点击</a><em></em>
                        <ul>
                            <li><a href="https://qqq.wkquan.com/Fine/VTrafficTask/Index">发布流量任务</a></li>
                            <li><a href="https://qqq.wkquan.com/Fine/VTrafficTask/TaskIndex">流量任务管理</a></li>
                        </ul>
                    </li> 
                <li><a id="ShopPay">资金管理</a><em></em>
                    <ul>
                        <li><a href="https://qqq.wkquan.com/Shop/InCome/NewIncomeIndex">账号充值</a></li>
                        <li id="transferManagement"><a href="https://qqq.wkquan.com/Shop/TransferManagement/Index">转账管理</a>
                        </li>
                        <li><a href="https://qqq.wkquan.com/Member/MemberInfo/ShopMemberDuiHuan">发布点兑换</a></li>
                        <li><a href="https://qqq.wkquan.com/Member/MemberInfo/ShopGetRecordList">资金管理</a></li>
                        <li><a href="https://qqq.wkquan.com/Member/MemberInfo/FShopPayList">订单信息</a></li>
                    </ul>
                </li>
                <li><a id="NewMember">会员中心</a><em></em>
                    <ul>
                        <li><a href="https://qqq.wkquan.com/Member/MemberInfo/NewMemberInfo" id="NewMemberInfo">基本资料</a></li>
                        <li><a href="https://qqq.wkquan.com/Member/PlatformNOAssistant/Index">智能助手</a></li>
                        <li><a href="https://qqq.wkquan.com/Shop/PlatformNo/Index">店铺管理</a></li>
                        <li><a href="https://qqq.wkquan.com/Shop/Product/ProductIndex">商品管理</a></li>
                        
                        <li><a href="https://qqq.wkquan.com/Other/Content/NewContentIndex">平台公告</a></li>
                        <li><a href="https://qqq.wkquan.com/Shop/PlatformNo/PublishNumIndex">调整单量</a>
                        </li>
                    </ul>
                </li>
                <li><a href="https://qqq.wkquan.com/NewSchedual/NewSchedual/SchedualList" id="Schedual">客服工单</a></li>
            </ul>
        </div>
    </div>
    <!--daohang-->
    
    
    <!-- 内容-->
    <div class="sj-fprw">
<form action="https://qqq.wkquan.com/Fine/VTask" enctype="multipart/form-data" id="fm" method="post">            <!-- tab切换-->
            <div class="tab1" id="tab1">
<style>
    .infobox
    {
        background-color: #fff9d7;
        border: 1px solid #e2c822;
        color: #333333;
        padding: 5px;
        padding-left: 30px;
        font-size: 13px;
        --font-weight: bold;
        margin: 0 auto;
        margin-top: 10px;
        margin-bottom: 10px;
        width: 85%;
        text-align: left;
    }
    .errorbox
    {
        background-color: #ffebe8;
        border: 1px solid #dd3c10;
        margin: 0 auto;
        margin-top: 10px;
        margin-bottom: 10px;
        color: #333333;
        padding: 5px;
        padding-left: 30px;
        font-size: 13px;
        --font-weight: bold;
        width: 85%;
    }
</style>
                <div class="menu">
                    <ul>
                        <li id="one2" onclick="location.href=&#39;/Fine/VMTask&#39;">发布任务</li>
                        <li id="one1" class="off" onclick="location.href=&#39;/Fine/VTask&#39;">任务管理</li>
                        <li id="one0" onclick="location.href=&#39;/Fine/VEvaluateTask&#39;">评价管理</li>
                    </ul>
                </div>
                <div class="menudiv">
                    <div id="con_one_2">
                        <div class="fpgl-ss">
                            <p>
                                
                                <select class="select_215" id="taskCategroy" name="taskCategroy" style="width:120px;"><option value="">任务分类</option>
<option value="0">销量任务</option>
<option value="1">浏览推送任务</option>
<option value="2">加购物车推送任务</option>
<option value="3">收藏商品推送任务</option>
<option value="4">商品复购推送任务</option>
<option value="5">店铺复购推送任务</option>
</select>
                                <select class="select_215" id="status" name="status" style="width:120px;"><option value="">全部任务</option>
<option value="6">隐藏任务</option>
<option value="0">待接手</option>
<option value="1">进行中</option>
<option value="2">待发货</option>
<option value="3">待评价</option>
<option value="4">待完成</option>
<option value="5">已完成</option>
<option value="7">已取消</option>
</select>
                                <select class="select_215" id="selSearch" name="selSearch" style="width:120px;"><option value="TaskID">任务编号</option>
<option value="OrderID">订单编号</option>
<option value="WaybillNumber">运单号</option>
<option value="ShopName">店铺名称</option>
<option value="PlatformNumber">买号</option>
<option value="ProductPlatformID">商品ID</option>
<option value="ShortName">商品简称</option>
</select>
                            </p>
                            <p>
                                <input class="input_417" id="txtSearch" name="txtSearch" style="width:90px;" type="text" value="">
                                </p>
                            <p>
                                发布时间:<input class="laydate-icon" id="BeginDate" maxlength="16" name="BeginDate" onclick="laydate({istime: true, format: &#39;YYYY-MM-DD hh:mm&#39;})" style="width:118px;height:34px;margin-left:5px;" type="text" value="">
                                ~
                                <input class="laydate-icon" id="EndDate" maxlength="16" name="EndDate" onclick="laydate({istime: true, format: &#39;YYYY-MM-DD hh:mm&#39;})" style="width:118px;height:34px;" type="text" value="">
                            </p>
                            <p>
                                <input class="input-butto100-ls" style="width: 80px" type="submit" value="查询"></p>
                            <p>
                                <input class="input-butto100-hs" style="width:80px" type="button" value="刷新" onclick="location.href=&#39;/Fine/VTask&#39;"></p>
                            <p class="disquxioa">
                                <input id="btnCancel" onclick="CancelAllTask()" class="input-butto100-xxshs" disabled="disabled" style="width: 80px;" type="button" value="批量取消">
                                <span class="diszhushi"><em></em>查询条件为<b style="color: Red; font-weight: 900">"待接手"</b>或<b style="color: Red; font-weight: 900">"隐藏任务"</b>，才能进行批量取消任务操作。 </span>
                            </p>
                        </div>
                        <!-- 搜索-->
                        <!-- 表格-->
                        <div class="fprw-pg">
                            <table>
                                <tbody><tr align="center">
                                    <th width="100">
                                        <center>
                                            任务分类</center>
                                    </th>
                                    <th width="280">
                                        <center>
                                            任务/订单编号</center>
                                    </th>
                                    <th width="220">
                                        <center>
                                            买号/商品信息</center>
                                    </th>
                                    <th width="220">
                                        <center>
                                            商品价格/发布点</center>
                                    </th>
                                    <th width="232">
                                        <center>
                                            任务状态</center>
                                    </th>
                                    <th width="132">
                                        <center>
                                            操作按钮</center>
                                    </th>
                                </tr>
                                    <tr>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                加购物车推送任务
                                                    <b style="color: Red">(预约任务)</b>
                                            </p>
                                        </td>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                任务编号：V6588014386<b style="color: Red">(淘宝APP自然搜索)</b></p>
                                                <p class="fpgl-td-rw">
                                                    订单编号：13270078496105140</p>
                                                <p class="fpgl-td-rw">
                                                    圆通快递：808019801201</p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                                <p class="fpgl-td-rw">
                                                    买号：112313chen</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>
                                                            <a href="javascript:viod(0)" onclick="LookBuyNumberInfo(&#39;495a9324-a5ec-4115-ab9c-97fcb7fef58a&#39;)" style="color: #5ca7f5">
                                                                查看买号信息</a>
                                                    </strong>
                                                </p>
                                            <p class="fpgl-td-rw">
                                                店铺名称：sandyjack旗舰店</p>
                                            <p class="fpgl-td-rw">
                                                <strong><a href="javascript:viod(0)" onclick="GetTaskDatailInfo(&#39;V6588014386&#39;)" style="color: #5ca7f5">
                                                    查看任务详情</a></strong> <strong style="margin-left: 20px"><a href="javascript:viod(0)" onclick="EditTaskRemark(&#39;V6588014386&#39;)" style="color: #5ca7f5">
                                                        修改备注</a></strong></p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <center>
                                                <p class="fpgl-td-rw">
                                                    商品价格：258.00 元
                                                </p>
                                                <p class="fpgl-td-rw">
                                                    发布点：20.00 个</p>
                                                    <p class="fpgl-td-rw">
                                                        转账方式：<em style="color: Red">自行转账</em></p>
                                                <br>
                                                    <p class="fpgl-td-rw">
                                                        <span style="color: Red; margin-left: 40px;"> </span>
                                                    </p>
                                            </center>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <p class="fpgl-td-rw" style="text-align: center">
                                                <strong><a href="javascript:void(0)" onclick="ShowOptLog(&#39;V6588014386&#39;)" style="color: #5ca7f5">已完成</a></strong></p>
                                            <p class="fpgl-td-rw">
                                                <strong>发布时间：</strong>2017/07/06 17:30</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>接手时间：</strong>2017/07/06 17:38</p>
                                            <p class="fpgl-td-rw">
                                                <a href="javascript:void()" onclick="$.openAlter(&#39;&#39;,&#39;处罚原因&#39;)"><span style="color: red"> </span></a>
                                            </p>
                                        </td>
                                        <td>
                                                <p class="fpgl-td-mtop">
                                                    <input onclick="GetPictures(&#39;V6588014386&#39;)" class="input-butto100-xshs" type="button" value="已查看"></p>
                                                <p class="fpgl-td-mtop">
                                                    <input onclick="CreateTaskError(&#39;V6588014386&#39;)" class="input-butto100-xhs" type="button" value="客服介入"></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                销量任务
                                            </p>
                                        </td>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                任务编号：V6588007336<b style="color: Red">(淘宝APP自然搜索)</b></p>
                                                <p class="fpgl-td-rw">
                                                    订单编号：21539522266269711</p>
                                                <p class="fpgl-td-rw">
                                                    圆通快递：808016763080</p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                                <p class="fpgl-td-rw">
                                                    买号：陈峰峰1314520</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>
                                                            <a href="javascript:viod(0)" onclick="LookBuyNumberInfo(&#39;29e2650f-44aa-480f-9f78-352bb8e2a29a&#39;)" style="color: #5ca7f5">
                                                                查看买号信息</a>
                                                    </strong>
                                                </p>
                                            <p class="fpgl-td-rw">
                                                店铺名称：sandyjack旗舰店</p>
                                            <p class="fpgl-td-rw">
                                                <strong><a href="javascript:viod(0)" onclick="GetTaskDatailInfo(&#39;V6588007336&#39;)" style="color: #5ca7f5">
                                                    查看任务详情</a></strong> <strong style="margin-left: 20px"><a href="javascript:viod(0)" onclick="EditTaskRemark(&#39;V6588007336&#39;)" style="color: #5ca7f5">
                                                        修改备注</a></strong></p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <center>
                                                <p class="fpgl-td-rw">
                                                    商品价格：288.00 元
                                                </p>
                                                <p class="fpgl-td-rw">
                                                    发布点：27.00 个</p>
                                                    <p class="fpgl-td-rw">
                                                        转账方式：<em style="color: Red">自行转账</em></p>
                                                <br>
                                                    <p class="fpgl-td-rw">
                                                        <span style="color: Red; margin-left: 40px;"> </span>
                                                    </p>
                                            </center>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <p class="fpgl-td-rw" style="text-align: center">
                                                <strong><a href="javascript:void(0)" onclick="ShowOptLog(&#39;V6588007336&#39;)" style="color: #5ca7f5">已完成</a></strong></p>
                                            <p class="fpgl-td-rw">
                                                <strong>发布时间：</strong>2017/05/31 10:52</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>接手时间：</strong>2017/05/31 10:54</p>
                                            <p class="fpgl-td-rw">
                                                <a href="javascript:void()" onclick="$.openAlter(&#39;&#39;,&#39;处罚原因&#39;)"><span style="color: red"> </span></a>
                                            </p>
                                        </td>
                                        <td>
                                                <p class="fpgl-td-mtop">
                                                    <input onclick="CreateTaskError(&#39;V6588007336&#39;)" class="input-butto100-xhs" type="button" value="客服介入"></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                销量任务
                                            </p>
                                        </td>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                任务编号：V6588002632<b style="color: Red">(淘宝PC自然搜索)</b></p>
                                                <p class="fpgl-td-rw">
                                                    订单编号：9059620555490108</p>
                                                <p class="fpgl-td-rw">
                                                    圆通快递：808014276079</p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                                <p class="fpgl-td-rw">
                                                    买号：zhonghanghan</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>
                                                            <a href="javascript:viod(0)" onclick="LookBuyNumberInfo(&#39;a6ee1da3-d3fa-439b-a0d4-1f3b3bc80fc8&#39;)" style="color: #5ca7f5">
                                                                查看买号信息</a>
                                                    </strong>
                                                </p>
                                            <p class="fpgl-td-rw">
                                                店铺名称：sandyjack旗舰店</p>
                                            <p class="fpgl-td-rw">
                                                <strong><a href="javascript:viod(0)" onclick="GetTaskDatailInfo(&#39;V6588002632&#39;)" style="color: #5ca7f5">
                                                    查看任务详情</a></strong> <strong style="margin-left: 20px"><a href="javascript:viod(0)" onclick="EditTaskRemark(&#39;V6588002632&#39;)" style="color: #5ca7f5">
                                                        修改备注</a></strong></p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <center>
                                                <p class="fpgl-td-rw">
                                                    商品价格：288.00 元
                                                </p>
                                                <p class="fpgl-td-rw">
                                                    发布点：21.00 个</p>
                                                    <p class="fpgl-td-rw">
                                                        转账方式：<em style="color: Red">自行转账</em></p>
                                                <br>
                                                    <p class="fpgl-td-rw">
                                                        <span style="color: Red; margin-left: 40px;"> </span>
                                                    </p>
                                            </center>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <p class="fpgl-td-rw" style="text-align: center">
                                                <strong><a href="javascript:void(0)" onclick="ShowOptLog(&#39;V6588002632&#39;)" style="color: #5ca7f5">已完成</a></strong></p>
                                            <p class="fpgl-td-rw">
                                                <strong>发布时间：</strong>2017/04/22 17:24</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>接手时间：</strong>2017/04/22 22:58</p>
                                            <p class="fpgl-td-rw">
                                                <a href="javascript:void()" onclick="$.openAlter(&#39;&#39;,&#39;处罚原因&#39;)"><span style="color: red"> </span></a>
                                            </p>
                                        </td>
                                        <td>
                                                <p class="fpgl-td-mtop">
                                                    <input onclick="CreateTaskError(&#39;V6588002632&#39;)" class="input-butto100-xhs" type="button" value="客服介入"></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                销量任务
                                            </p>
                                        </td>
                                        <td>
                                            <p class="fpgl-td-rw">
                                                任务编号：V6588002337<b style="color: Red">(淘宝PC自然搜索)</b></p>
                                                <p class="fpgl-td-rw">
                                                    订单编号：3223583422552103</p>
                                                <p class="fpgl-td-rw">
                                                    圆通快递：808013830637</p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                                <p class="fpgl-td-rw">
                                                    买号：pdsquan1</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>
                                                            <a href="javascript:viod(0)" onclick="LookBuyNumberInfo(&#39;704b9258-ac79-4144-9286-b3b8b1b0a97d&#39;)" style="color: #5ca7f5">
                                                                查看买号信息</a>
                                                    </strong>
                                                </p>
                                            <p class="fpgl-td-rw">
                                                店铺名称：sandyjack旗舰店</p>
                                            <p class="fpgl-td-rw">
                                                <strong><a href="javascript:viod(0)" onclick="GetTaskDatailInfo(&#39;V6588002337&#39;)" style="color: #5ca7f5">
                                                    查看任务详情</a></strong> <strong style="margin-left: 20px"><a href="javascript:viod(0)" onclick="EditTaskRemark(&#39;V6588002337&#39;)" style="color: #5ca7f5">
                                                        修改备注</a></strong></p>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <center>
                                                <p class="fpgl-td-rw">
                                                    商品价格：288.00 元
                                                </p>
                                                <p class="fpgl-td-rw">
                                                    发布点：21.00 个</p>
                                                    <p class="fpgl-td-rw">
                                                        转账方式：<em style="color: Red">平台转账</em></p>
                                                <br>
                                                    <p class="fpgl-td-rw">
                                                        <span style="color: Red; margin-left: 40px;"> </span>
                                                    </p>
                                            </center>
                                        </td>
                                        <td class="fpgl-td-zs">
                                            <p class="fpgl-td-rw" style="text-align: center">
                                                <strong><a href="javascript:void(0)" onclick="ShowOptLog(&#39;V6588002337&#39;)" style="color: #5ca7f5">已完成</a></strong></p>
                                            <p class="fpgl-td-rw">
                                                <strong>发布时间：</strong>2017/04/15 15:46</p>
                                                <p class="fpgl-td-rw">
                                                    <strong>接手时间：</strong>2017/04/15 15:50</p>
                                            <p class="fpgl-td-rw">
                                                <a href="javascript:void()" onclick="$.openAlter(&#39;&#39;,&#39;处罚原因&#39;)"><span style="color: red"> </span></a>
                                            </p>
                                        </td>
                                        <td>
                                                <p class="fpgl-td-mtop">
                                                    <input onclick="CreateTaskError(&#39;V6588002337&#39;)" class="input-butto100-xhs" type="button" value="客服介入"></p>
                                        </td>
                                    </tr>
                            </tbody></table>
                        </div>
                        <!-- 表格-->
                    </div>
                </div>
            </div>
            <!-- tab切换-->
</form>    </div>
    <!-- 内容-->


<style type="text/css">
        /* online */
        #online_qq_tab a, .onlineMenu h3, .onlineMenu li.tli, .newpage
        {
            background: url(/Content/images/float_s.gif) no-repeat;
        }
        #onlineService, .onlineMenu, .btmbg
        {
            background: url(/Content/images/float_bg.gif) no-repeat;
        }
        
        #online_qq_layer
        {
            z-index: 9999;
            position: fixed;
            right: 0px;
            top: 0;
            margin: 150px 0 0 0;
        }
        *html, *html body
        {
            background-image: url(about:blank);
            background-attachment: fixed;
        }
        *html #online_qq_layer
        {
            position: absolute;
            top: expression(eval(document.documentElement.scrollTop));
        }
        
        #online_qq_tab
        {
            width: 28px;
            float: left;
            margin: 403px 0 0 0;
            position: relative;
            z-index: 9;
        }
        #online_qq_tab a
        {
            display: block;
            height: 118px;
            line-height: 999em;
            overflow: hidden;
        }
        #online_qq_tab a#floatShow
        {
            background-position: -30px -374px;
        }
        #online_qq_tab a#floatHide
        {
            background-position: 0 -374px;
        }
        
        #onlineService
        {
            display: inline;
            margin-left: -1px;
            float: left;
            width: 130px;
            background-position: 0 0;
            padding: 10px 0 0 0;
            margin-top:400px
        }
        .onlineMenu
        {
            background-position: -262px 0;
            background-repeat: repeat-y;
            padding: 0 15px;
        }
        .onlineMenu h3
        {
            height: 36px;
            line-height: 999em;
            overflow: hidden;
            border-bottom: solid 1px #ACE5F9;
        }
        .onlineMenu h3.tQQ
        {
            background-position: 0 10px;
        }
        .onlineMenu h3.tele
        {
            background-position: 0 -47px;
        }
        .onlineMenu li
        {
            height: 36px;
            line-height: 36px;
            border-bottom: solid 1px #E6E5E4;
            text-align: center;
        }
        .onlineMenu li.tli
        {
            padding: 0 0 0 28px;
            font-size: 12px;
            text-align: left;
        }
        .onlineMenu li.zixun
        {
            background-position: 0px -131px;
        }
        .onlineMenu li.fufei
        {
            background-position: 0px -190px;
        }
        .onlineMenu li.phone
        {
            background-position: 0px -244px;
        }
        .onlineMenu li a.newpage
        {
            display: block;
            height: 36px;
            line-height: 999em;
            overflow: hidden;
            background-position: 5px -100px;
        }
        .onlineMenu li img
        {
            margin: 8px 0 0 0;
        }
        .onlineMenu li.last
        {
            border: 0;
        }
        
        .wyzx
        {
            padding: 8px 0 0 5px;
            height: 57px;
            overflow: hidden;
            background: url(/Content/images/webZx_bg.jpg) no-repeat;
        }
        
        .btmbg
        {
            height: 12px;
            overflow: hidden;
            background-position: -131px 0;
        }
    </style>
<script language="javascript" type="text/javascript">
$(function(){
 

if(screen.width<1440)
{  
     var height = document.body.clientHeight;  

         $("#onlineService").css("margin-top", "300px"); 
         $("#online_qq_tab").css("margin-top","300px"); 
    // 拖拉事件计算foot div高度  
    $(window).scroll(function () {  
        var scrollDiff = document.body.scrollTop //  拖拉处的位移  
        $("#onlineService").css("margin-top", "300px"); 
         $("#online_qq_tab").css("margin-top","300px"); // 重计算底部位置  
    });  
}
else if(screen.width == 1024){
         $("#onlineService").css("margin-top", "260px"); 
         $("#online_qq_tab").css("margin-top","260px");

            $(window).scroll(function () {  
        var scrollDiff = document.body.scrollTop //  拖拉处的位移  
        $("#onlineService").css("margin-top", "260px"); 
         $("#online_qq_tab").css("margin-top","260px"); // 重计算底部位置  
    });  
 }
 else
 {
  $("#onlineService").css("margin-top", "420px"); 
         $("#online_qq_tab").css("margin-top","420px"); 
    // 拖拉事件计算foot div高度  
    $(window).scroll(function () {  
        var scrollDiff = document.body.scrollTop //  拖拉处的位移  
        $("#onlineService").css("margin-top", "420px"); 
         $("#online_qq_tab").css("margin-top","420px"); // 重计算底部位置  
    });  
 }
          // 拖拉事件计算foot div高度  
 
});
    $(document).ready(function () {
        var loginName='霆宇包包';
        var memberType='商家';
        var member='商家';
        if(member==memberType){
            $("#consultLi").show();
//            $("#online_qq_tab").css("margin-top","420px");
        }
        else {
            $("#consultLi").hide();
        }
        $("#online_qq_layer").show();
        
        $("#floatShow").bind("click", function () {

            $("#onlineService").animate({ width: "show", opacity: "show" }, "normal", function () {
                $("#onlineService").show();
            });

            $("#floatShow").attr("style", "display:none");
            $("#floatHide").attr("style", "display:block");
            return false;
        });

        $("#floatHide").bind("click", function () {

            $("#onlineService").animate({ width: "hide", opacity: "hide" }, "normal", function () {
                $("#onlineService").hide();
            });
            $("#floatShow").attr("style", "display:block");
            $("#floatHide").attr("style", "display:none");
            return false;
        });

        $.ajax({
                type: "get",
                cache:false,
                url: "/Home/GetConsultQQ",
                data:{id:loginName},
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    
                },
                success: function (data) {
                    if(data!=""){
                        var href='http://wpa.qq.com/msgrd?v=3&uin='+data+'&site=在线客服&menu=yes';
                        $("#consultQQ").attr('href',href);
                    }
                }
            });
        $.ajax({
                type: "get",
                cache:false,
                url: "/Home/GetServiceQQ",
                dataType: "json",
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    
                },
                success: function (data) {
                    if(data!=""){
                        var href='http://wpa.qq.com/msgrd?v=3&uin='+data+'&site=在线客服&menu=yes';
                        $("#serviceQQ").attr('href',href);
                    }
                }
            });

    });
    $(window)

</script>
<div id="online_qq_layer" style="height: 50px;">
    <div id="online_qq_tab" style="margin-top: 420px;">
        <a id="floatShow" style="display: none;" href="javascript:void(0);">收缩</a> 
        <a id="floatHide" style="display: block;" href="javascript:void(0);">展开</a>
    </div>
    <div id="onlineService" style="margin-top: 420px;">
        <div class="onlineMenu">
            <h3 class="tQQ">
                QQ在线客服</h3>
            <ul>
                <li class="tli zixun">在线咨询</li>
                
                <li id="consultLi" style="height:30px"><a target="_blank" style="font-size:13px" id="consultQQ" href="http://wpa.qq.com/msgrd?v=3&amp;uin=3272369440&amp;site=%E5%9C%A8%E7%BA%BF%E5%AE%A2%E6%9C%8D&amp;menu=yes" title="点击可进行QQ交流">
                    <img width="25" height="17" border="0" align="absmiddle" style="vertical-align:text-bottom" src="./Index_files/qq_online.gif">&nbsp;商家顾问</a>
                </li>
                    
                <li style="height:30px"><a target="_blank" id="serviceQQ" style="font-size:13px" href="http://wpa.qq.com/msgrd?v=3&amp;uin=800186664&amp;site=%E5%9C%A8%E7%BA%BF%E5%AE%A2%E6%9C%8D&amp;menu=yes" title="点击可进行QQ交流">
                    <img width="25" height="17" border="0" align="absmiddle" style="vertical-align:text-bottom" src="./Index_files/qq_online.gif">&nbsp;平台客服</a>
                </li>
            </ul>
        </div>
        
        
        <div class="btmbg">
        </div>
    </div>
</div>


<div id="ow001" class="ow_black_overlay" style="height: 1059px; width: 1903px;"></div><div id="ow002" class="ow_ycgl_tc" style="height: 590px; width: 550px; left: 676.5px; top: 167.5px;"><iframe scrolling="no" frameborder="0" src="./Index_files/CreateTaskError.html" style="width:100%;height:100%;"></iframe></div></body></html>